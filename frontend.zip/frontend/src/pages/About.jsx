import React from 'react'
import { Shield, Target, Eye, Users, Award, Clock, CheckCircle } from 'lucide-react'

const About = () => {
  const values = [
    {
      icon: Shield,
      title: "Safety First",
      description: "Every decision we make prioritizes the safety of people and property."
    },
    {
      icon: Target,
      title: "Excellence",
      description: "We strive for excellence in every project, no matter the size."
    },
    {
      icon: Users,
      title: "Integrity",
      description: "Honest, transparent, and reliable service to all our clients."
    },
    {
      icon: Award,
      title: "Innovation",
      description: "Continuously improving our methods and embracing new technologies."
    }
  ]

  const milestones = [
    { year: "2003", title: "Company Founded", description: "Started with a vision to make fire safety accessible to all businesses." },
    { year: "2008", title: "First Major Contract", description: "Secured our first corporate client, marking our entry into commercial fire safety." },
    { year: "2013", title: "ISO Certification", description: "Achieved ISO 9001:2008 certification for quality management systems." },
    { year: "2018", title: "Technology Integration", description: "Launched smart fire detection systems with IoT capabilities." },
    { year: "2023", title: "20th Anniversary", description: "Celebrated two decades of protecting lives and property." }
  ]

  const certifications = [
    "NFPA Certified Fire Protection Specialist",
    "ISO 9001:2015 Quality Management",
    "OSHA Safety Training Certified",
    "State Fire Marshal Licensed",
    "UL Listed Equipment Installation"
  ]

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-primary-600 via-primary-700 to-primary-800 text-white py-20">
        <div className="container-custom text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            About FireGuard Pro
          </h1>
          <p className="text-xl text-primary-100 max-w-3xl mx-auto">
            We are a leading Fire Fighting Services provider with 20+ years of expertise 
            in fire detection, suppression, and safety compliance.
          </p>
        </div>
      </section>

      {/* Company Overview */}
      <section className="section-padding bg-white">
        <div className="container-custom">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Our Story
              </h2>
              <p className="text-lg text-gray-600 mb-6">
                Founded in 2003, FireGuard Pro began with a simple mission: to protect lives 
                and assets through reliable fire safety systems. What started as a small local 
                business has grown into a trusted partner for hundreds of companies across the region.
              </p>
              <p className="text-lg text-gray-600 mb-6">
                Our journey has been driven by a commitment to excellence and a deep understanding 
                that fire safety is not just about compliance—it's about protecting what matters most.
              </p>
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <Clock className="w-5 h-5 text-primary-600" />
                  <span className="text-gray-600">20+ Years Experience</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Users className="w-5 h-5 text-primary-600" />
                  <span className="text-gray-600">500+ Projects</span>
                </div>
              </div>
            </div>
            <div className="relative">
              <div className="bg-gradient-to-br from-primary-100 to-fire-100 rounded-2xl p-8">
                <div className="text-center">
                  <Shield className="w-24 h-24 text-primary-600 mx-auto mb-4" />
                  <h3 className="text-2xl font-bold text-gray-900 mb-4">
                    Trusted by Industry Leaders
                  </h3>
                  <p className="text-gray-600">
                    From small businesses to Fortune 500 companies, we've earned the trust 
                    of organizations that prioritize safety and reliability.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="section-padding bg-gray-50">
        <div className="container-custom">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="card p-8 text-center">
              <div className="w-20 h-20 mx-auto mb-6 bg-gradient-to-br from-primary-500 to-primary-600 rounded-full flex items-center justify-center">
                <Target className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Our Mission</h3>
              <p className="text-gray-600">
                To protect lives and assets with reliable safety systems, providing peace of mind 
                to our clients through expert fire protection solutions and exceptional service.
              </p>
            </div>
            
            <div className="card p-8 text-center">
              <div className="w-20 h-20 mx-auto mb-6 bg-gradient-to-br from-fire-500 to-fire-600 rounded-full flex items-center justify-center">
                <Eye className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Our Vision</h3>
              <p className="text-gray-600">
                A fire-safe world where safety comes first, where every building and facility 
                is protected by advanced fire safety systems that prevent disasters before they happen.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Core Values */}
      <section className="section-padding bg-white">
        <div className="container-custom">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Our Core Values
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              These principles guide everything we do and shape the way we serve our clients.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-primary-500 to-fire-500 rounded-full flex items-center justify-center">
                  <value.icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">
                  {value.title}
                </h3>
                <p className="text-gray-600">
                  {value.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Milestones */}
      <section className="section-padding bg-gray-50">
        <div className="container-custom">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Our Journey
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Key milestones that have shaped our company and our commitment to fire safety.
            </p>
          </div>

          <div className="relative">
            {/* Timeline Line */}
            <div className="absolute left-1/2 transform -translate-x-px h-full w-0.5 bg-primary-200"></div>
            
            <div className="space-y-12">
              {milestones.map((milestone, index) => (
                <div key={index} className={`relative flex items-center ${
                  index % 2 === 0 ? 'flex-row' : 'flex-row-reverse'
                }`}>
                  {/* Timeline Dot */}
                  <div className="absolute left-1/2 transform -translate-x-1/2 w-4 h-4 bg-primary-600 rounded-full border-4 border-white shadow-lg"></div>
                  
                  {/* Content */}
                  <div className={`w-5/12 ${index % 2 === 0 ? 'pr-8 text-right' : 'pl-8 text-left'}`}>
                    <div className="bg-white p-6 rounded-lg shadow-lg">
                      <div className="text-2xl font-bold text-primary-600 mb-2">
                        {milestone.year}
                      </div>
                      <h3 className="text-xl font-semibold text-gray-900 mb-2">
                        {milestone.title}
                      </h3>
                      <p className="text-gray-600">
                        {milestone.description}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Certifications */}
      <section className="section-padding bg-white">
        <div className="container-custom">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Certifications & Licenses
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Our team maintains the highest standards of professional certification and training.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {certifications.map((cert, index) => (
              <div key={index} className="flex items-center space-x-3 p-4 bg-gray-50 rounded-lg">
                <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                <span className="text-gray-700">{cert}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding fire-gradient text-white">
        <div className="container-custom text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Work with Us?
          </h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto opacity-90">
            Join hundreds of satisfied clients who trust FireGuard Pro with their fire safety needs. 
            Let's discuss how we can protect your business.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a href="/contact" className="bg-white text-fire-600 hover:bg-gray-100 font-semibold py-3 px-8 rounded-lg transition-all duration-200 transform hover:scale-105 shadow-lg">
              Get Started Today
            </a>
            <a href="/services" className="border-2 border-white text-white hover:bg-white hover:text-fire-600 font-semibold py-3 px-8 rounded-lg transition-all duration-200">
              View Our Services
            </a>
          </div>
        </div>
      </section>
    </div>
  )
}

export default About
