import React from 'react'
import { Link } from 'react-router-dom'
import { Star, Quote, Building, Users, Award, CheckCircle } from 'lucide-react'

const Clients = () => {
  const clients = [
    {
      name: "TechCorp Industries",
      logo: "TC",
      industry: "Technology",
      testimonial: "FireGuard Pro has been instrumental in ensuring our data centers meet the highest fire safety standards. Their expertise and attention to detail are unmatched.",
      rating: 5,
      contact: "Sarah Johnson, Facilities Manager"
    },
    {
      name: "Metro Healthcare",
      logo: "MH",
      industry: "Healthcare",
      testimonial: "Patient safety is our top priority. FireGuard Pro's fire suppression systems give us peace of mind knowing our facility is protected 24/7.",
      rating: 5,
      contact: "Dr. Michael Chen, Chief Medical Officer"
    },
    {
      name: "Global Manufacturing Co.",
      logo: "GM",
      industry: "Manufacturing",
      testimonial: "Their comprehensive fire safety audit identified critical gaps we didn't know existed. The implementation was smooth and professional.",
      rating: 5,
      contact: "Robert Martinez, Operations Director"
    },
    {
      name: "Skyline Properties",
      logo: "SP",
      industry: "Real Estate",
      testimonial: "Managing multiple properties requires reliable partners. FireGuard Pro consistently delivers exceptional service across all our locations.",
      rating: 5,
      contact: "Jennifer Lee, Property Manager"
    },
    {
      name: "City Center Mall",
      logo: "CC",
      industry: "Retail",
      testimonial: "With thousands of visitors daily, we need fire safety systems we can trust. FireGuard Pro has exceeded our expectations.",
      rating: 5,
      contact: "David Thompson, Security Director"
    },
    {
      name: "University Heights",
      logo: "UH",
      industry: "Education",
      testimonial: "Our students' safety is paramount. FireGuard Pro's training programs and safety systems have created a secure learning environment.",
      rating: 5,
      contact: "Dr. Patricia Williams, Campus Safety Officer"
    }
  ]

  const industries = [
    "Technology & Data Centers",
    "Healthcare & Hospitals",
    "Manufacturing & Industrial",
    "Real Estate & Commercial",
    "Retail & Shopping Centers",
    "Education & Universities",
    "Hotels & Hospitality",
    "Financial Services",
    "Government & Municipal",
    "Transportation & Logistics"
  ]

  const stats = [
    { number: "500+", label: "Projects Completed" },
    { number: "50+", label: "Industries Served" },
    { number: "98%", label: "Client Satisfaction" },
    { number: "24/7", label: "Support Available" }
  ]

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-primary-600 via-primary-700 to-primary-800 text-white py-20">
        <div className="container-custom text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            Our Clients
          </h1>
          <p className="text-xl text-primary-100 max-w-3xl mx-auto">
            Trusted by leading companies across diverse industries for their fire safety needs. 
            Discover why businesses choose FireGuard Pro for reliable protection.
          </p>
        </div>
      </section>

      {/* Stats Section */}
      <section className="section-padding bg-white">
        <div className="container-custom">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {stats.map((stat, index) => (
              <div key={index} className="p-6">
                <div className="text-3xl md:text-4xl font-bold text-primary-600 mb-2">
                  {stat.number}
                </div>
                <div className="text-gray-600 font-medium">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Client Testimonials */}
      <section className="section-padding bg-gray-50">
        <div className="container-custom">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              What Our Clients Say
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Real feedback from businesses that trust us with their fire safety needs.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {clients.map((client, index) => (
              <div key={index} className="card p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-primary-500 to-fire-500 rounded-lg flex items-center justify-center text-white font-bold text-lg">
                    {client.logo}
                  </div>
                  <div className="flex space-x-1">
                    {[...Array(client.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 text-yellow-400 fill-current" />
                    ))}
                  </div>
                </div>
                
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  {client.name}
                </h3>
                <p className="text-sm text-primary-600 mb-3">
                  {client.industry}
                </p>
                
                <div className="mb-4">
                  <Quote className="w-6 h-6 text-gray-300 mb-2" />
                  <p className="text-gray-600 italic">
                    "{client.testimonial}"
                  </p>
                </div>
                
                <p className="text-sm text-gray-500">
                  — {client.contact}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Industries We Serve */}
      <section className="section-padding bg-white">
        <div className="container-custom">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Industries We Serve
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Our expertise spans across diverse sectors, each with unique fire safety challenges 
              and requirements.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {industries.map((industry, index) => (
              <div key={index} className="flex items-center space-x-3 p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                <Building className="w-5 h-5 text-primary-600" />
                <span className="text-gray-800 font-medium">{industry}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Case Studies Preview */}
      <section className="section-padding bg-gray-50">
        <div className="container-custom">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Success Stories
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Real examples of how we've helped businesses achieve their fire safety goals.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="card p-8">
              <div className="w-16 h-16 mx-auto mb-6 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center">
                <Building className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4 text-center">
                Data Center Fire Safety
              </h3>
              <p className="text-gray-600 mb-4">
                Implemented comprehensive fire detection and suppression systems for a 
                major technology company's data center, ensuring 99.99% uptime and 
                complete asset protection.
              </p>
              <div className="text-center">
                <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800">
                  Technology Sector
                </span>
              </div>
            </div>

            <div className="card p-8">
              <div className="w-16 h-16 mx-auto mb-6 bg-gradient-to-br from-green-500 to-green-600 rounded-full flex items-center justify-center">
                <Users className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4 text-center">
                Hospital Emergency Systems
              </h3>
              <p className="text-gray-600 mb-4">
                Designed and installed advanced fire safety systems for a 500-bed hospital, 
                including specialized suppression systems for operating rooms and critical care areas.
              </p>
              <div className="text-center">
                <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-green-100 text-green-800">
                  Healthcare Sector
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Why Clients Choose Us */}
      <section className="section-padding bg-white">
        <div className="container-custom">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Why Clients Choose FireGuard Pro
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Our commitment to excellence and customer satisfaction sets us apart.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-primary-500 to-primary-600 rounded-full flex items-center justify-center">
                <Award className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Proven Track Record</h3>
              <p className="text-gray-600">
                20+ years of successful projects and satisfied clients across all industries.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-fire-500 to-fire-600 rounded-full flex items-center justify-center">
                <CheckCircle className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Quality Assurance</h3>
              <p className="text-gray-600">
                All systems meet or exceed industry standards and regulatory requirements.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-primary-500 to-primary-600 rounded-full flex items-center justify-center">
                <Users className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Expert Support</h3>
              <p className="text-gray-600">
                Dedicated account managers and 24/7 technical support for all clients.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding fire-gradient text-white">
        <div className="container-custom text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Join Our Growing Client Base
          </h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto opacity-90">
            Experience the FireGuard Pro difference. Contact us today to discuss 
            how we can protect your business with world-class fire safety solutions.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/contact" className="bg-white text-fire-600 hover:bg-gray-100 font-semibold py-3 px-8 rounded-lg transition-all duration-200 transform hover:scale-105 shadow-lg">
              Get Started Today
            </Link>
            <Link to="/services" className="border-2 border-white text-white hover:bg-white hover:text-fire-600 font-semibold py-3 px-8 rounded-lg transition-all duration-200">
              View Our Services
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}

export default Clients
