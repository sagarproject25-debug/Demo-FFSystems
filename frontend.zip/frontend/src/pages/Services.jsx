import React from 'react'
import { Link } from 'react-router-dom'
import { 
  Flame, 
  Droplets, 
  Wrench, 
  Users, 
  Building, 
  Shield, 
  CheckCircle, 
  ArrowRight,
  Phone,
  Mail
} from 'lucide-react'

const Services = () => {
  const services = [
    {
      icon: Flame,
      title: "Fire Detection & Alarm Systems",
      description: "Advanced smoke and heat detection systems with intelligent alarm monitoring and notification capabilities.",
      features: [
        "Smoke detectors and heat sensors",
        "Intelligent alarm control panels",
        "24/7 monitoring services",
        "Emergency notification systems",
        "Integration with building management"
      ],
      color: "from-red-500 to-red-600"
    },
    {
      icon: Droplets,
      title: "Fire Suppression Systems",
      description: "Comprehensive fire suppression solutions including sprinkler systems, gas suppression, and foam systems.",
      features: [
        "Automatic sprinkler systems",
        "Clean agent gas suppression",
        "Foam suppression systems",
        "Kitchen hood suppression",
        "Special hazard protection"
      ],
      color: "from-blue-500 to-blue-600"
    },
    {
      icon: Wrench,
      title: "Equipment Supply & Maintenance",
      description: "High-quality fire safety equipment supply and comprehensive maintenance services to ensure optimal performance.",
      features: [
        "Fire extinguishers and cabinets",
        "Emergency lighting systems",
        "Exit signs and wayfinding",
        "Preventive maintenance",
        "Emergency repair services"
      ],
      color: "from-green-500 to-green-600"
    },
    {
      icon: Users,
      title: "Emergency Response Training",
      description: "Comprehensive fire safety training programs for employees and emergency response teams.",
      features: [
        "Fire safety awareness training",
        "Evacuation procedures",
        "Fire extinguisher training",
        "Emergency response planning",
        "Regular safety drills"
      ],
      color: "from-purple-500 to-purple-600"
    },
    {
      icon: Building,
      title: "Building Fire Safety Compliance",
      description: "Complete compliance solutions ensuring your building meets all local and international fire safety regulations.",
      features: [
        "Fire safety audits and inspections",
        "Compliance documentation",
        "Code interpretation and guidance",
        "Permit assistance",
        "Regular compliance reviews"
      ],
      color: "from-orange-500 to-orange-600"
    },
    {
      icon: Shield,
      title: "Emergency Response Services",
      description: "24/7 emergency response services with rapid deployment of trained professionals and equipment.",
      features: [
        "24/7 emergency hotline",
        "Rapid response teams",
        "Emergency equipment deployment",
        "Coordination with local authorities",
        "Post-incident support"
      ],
      color: "from-indigo-500 to-indigo-600"
    }
  ]

  const additionalServices = [
    "Fire Safety Consulting",
    "Risk Assessment & Analysis",
    "Fire Safety Equipment Testing",
    "Emergency Lighting Design",
    "Fire Safety Signage",
    "Fire Safety Documentation"
  ]

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-primary-600 via-primary-700 to-primary-800 text-white py-20">
        <div className="container-custom text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            Our Services
          </h1>
          <p className="text-xl text-primary-100 max-w-3xl mx-auto">
            Comprehensive fire safety solutions designed to protect your business, 
            employees, and assets with cutting-edge technology and expert service.
          </p>
        </div>
      </section>

      {/* Services Grid */}
      <section className="section-padding bg-white">
        <div className="container-custom">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div key={index} className="card p-6 hover:shadow-2xl transition-all duration-300">
                <div className={`w-16 h-16 mx-auto mb-6 bg-gradient-to-br ${service.color} rounded-full flex items-center justify-center`}>
                  <service.icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4 text-center">
                  {service.title}
                </h3>
                <p className="text-gray-600 mb-6 text-center">
                  {service.description}
                </p>
                <ul className="space-y-2 mb-6">
                  {service.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-start space-x-2">
                      <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                      <span className="text-sm text-gray-600">{feature}</span>
                    </li>
                  ))}
                </ul>
                <div className="text-center">
                  <Link 
                    to="/contact" 
                    className="inline-flex items-center text-primary-600 hover:text-primary-700 font-medium transition-colors"
                  >
                    Learn More
                    <ArrowRight className="w-4 h-4 ml-1" />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Additional Services */}
      <section className="section-padding bg-gray-50">
        <div className="container-custom">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Additional Services
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Beyond our core offerings, we provide specialized services to meet 
              your unique fire safety requirements.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {additionalServices.map((service, index) => (
              <div key={index} className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
                <div className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-primary-600" />
                  <span className="text-gray-800 font-medium">{service}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Service Process */}
      <section className="section-padding bg-white">
        <div className="container-custom">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Our Service Process
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              A systematic approach to delivering exceptional fire safety solutions 
              tailored to your specific needs.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-primary-500 to-primary-600 rounded-full flex items-center justify-center text-white font-bold text-xl">
                1
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Assessment</h3>
              <p className="text-gray-600">
                Comprehensive evaluation of your current fire safety systems and requirements.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-fire-500 to-fire-600 rounded-full flex items-center justify-center text-white font-bold text-xl">
                2
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Planning</h3>
              <p className="text-gray-600">
                Custom solution design and project planning tailored to your needs.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-primary-500 to-primary-600 rounded-full flex items-center justify-center text-white font-bold text-xl">
                3
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Implementation</h3>
              <p className="text-gray-600">
                Professional installation and setup of all fire safety systems.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-fire-500 to-fire-600 rounded-full flex items-center justify-center text-white font-bold text-xl">
                4
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Support</h3>
              <p className="text-gray-600">
                Ongoing maintenance, monitoring, and support services.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="section-padding bg-gray-50">
        <div className="container-custom">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Why Choose FireGuard Pro?
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Our commitment to excellence and safety sets us apart in the industry.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-primary-500 to-primary-600 rounded-full flex items-center justify-center">
                <Shield className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Expert Team</h3>
              <p className="text-gray-600">
                Certified professionals with decades of experience in fire safety systems.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-fire-500 to-fire-600 rounded-full flex items-center justify-center">
                <CheckCircle className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Quality Assurance</h3>
              <p className="text-gray-600">
                All systems meet or exceed industry standards and regulatory requirements.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-primary-500 to-primary-600 rounded-full flex items-center justify-center">
                <Phone className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">24/7 Support</h3>
              <p className="text-gray-600">
                Round-the-clock emergency response and technical support when you need it most.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding fire-gradient text-white">
        <div className="container-custom text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Get Started?
          </h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto opacity-90">
            Contact us today for a free consultation and quote. Our experts are ready 
            to discuss your fire safety needs and provide customized solutions.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/contact" className="bg-white text-fire-600 hover:bg-gray-100 font-semibold py-3 px-8 rounded-lg transition-all duration-200 transform hover:scale-105 shadow-lg">
              Get Free Quote
            </Link>
            <div className="flex items-center space-x-2 text-white">
              <Phone className="w-5 h-5" />
              <span>+1 (555) 123-4567</span>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default Services
