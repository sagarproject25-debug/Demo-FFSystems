import React, { useState } from 'react'
import { MessageCircle, X, Send, CheckCircle } from 'lucide-react'

const ChatBot = () => {
  const [isOpen, setIsOpen] = useState(false)
  const [currentStep, setCurrentStep] = useState(0)
  const [formData, setFormData] = useState({
    name: '',
    company: '',
    email: '',
    service: '',
    notes: ''
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)

  const steps = [
    { field: 'name', label: 'What is your name?', placeholder: 'Enter your full name' },
    { field: 'company', label: 'What company do you represent?', placeholder: 'Enter company name' },
    { field: 'email', label: 'What is your email address?', placeholder: 'Enter your email' },
    { field: 'service', label: 'Which service are you interested in?', placeholder: 'e.g., Fire Detection, Suppression Systems' },
    { field: 'notes', label: 'Any additional notes or requirements?', placeholder: 'Optional - describe your needs' }
  ]

  const handleInputChange = (value) => {
    const currentField = steps[currentStep].field
    setFormData(prev => ({
      ...prev,
      [currentField]: value
    }))
  }

  const handleNext = () => {
    if (formData[steps[currentStep].field].trim()) {
      if (currentStep < steps.length - 1) {
        setCurrentStep(prev => prev + 1)
      } else {
        handleSubmit()
      }
    }
  }

  const handleSubmit = async () => {
    setIsSubmitting(true)
    try {
                const response = await fetch(`${import.meta.env.VITE_API_URL || 'http://localhost:5000'}/api/enquiry/submit`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      })

      if (response.ok) {
        setIsSubmitted(true)
        setTimeout(() => {
          setIsOpen(false)
          setCurrentStep(0)
          setFormData({
            name: '',
            company: '',
            email: '',
            service: '',
            notes: ''
          })
          setIsSubmitted(false)
        }, 3000)
      } else {
        throw new Error('Failed to submit enquiry')
      }
    } catch (error) {
      console.error('Error submitting enquiry:', error)
      alert('Failed to submit enquiry. Please try again.')
    } finally {
      setIsSubmitting(false)
    }
  }

  const resetChat = () => {
    setCurrentStep(0)
    setFormData({
      name: '',
      company: '',
      email: '',
      service: '',
      notes: ''
    })
    setIsSubmitted(false)
  }

  if (isSubmitted) {
    return (
      <div className="fixed bottom-6 right-6 z-50">
        <div className="bg-white rounded-2xl shadow-2xl p-6 w-80 animate-fade-in">
          <div className="text-center">
            <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-800 mb-2">
              Thank you!
            </h3>
            <p className="text-gray-600">
              We will contact you soon regarding your fire safety needs.
            </p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <>
      {/* Chat Button */}
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 z-40 bg-primary-600 hover:bg-primary-700 text-white p-4 rounded-full shadow-2xl transition-all duration-200 transform hover:scale-110"
      >
        <MessageCircle className="w-6 h-6" />
      </button>

      {/* Chat Window */}
      {isOpen && (
        <div className="fixed bottom-6 right-6 z-50">
          <div className="bg-white rounded-2xl shadow-2xl w-80 animate-slide-up">
            {/* Header */}
            <div className="bg-gradient-to-r from-primary-600 to-fire-500 text-white p-4 rounded-t-2xl">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
                    <MessageCircle className="w-4 h-4" />
                  </div>
                  <span className="font-semibold">Fire Safety Assistant</span>
                </div>
                <button
                  onClick={() => setIsOpen(false)}
                  className="text-white hover:text-gray-200 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Chat Content */}
            <div className="p-4">
              {currentStep < steps.length ? (
                <div className="space-y-4">
                  <div className="bg-gray-100 rounded-lg p-3">
                    <p className="text-gray-800 font-medium">
                      {steps[currentStep].label}
                    </p>
                  </div>
                  
                  <div className="space-y-3">
                    <input
                      type="text"
                      value={formData[steps[currentStep].field]}
                      onChange={(e) => handleInputChange(e.target.value)}
                      placeholder={steps[currentStep].placeholder}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                      onKeyPress={(e) => e.key === 'Enter' && handleNext()}
                    />
                    
                    <button
                      onClick={handleNext}
                      disabled={!formData[steps[currentStep].field].trim() || isSubmitting}
                      className="w-full btn-primary disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
                    >
                      {isSubmitting ? (
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      ) : (
                        <Send className="w-4 h-4" />
                      )}
                      <span>
                        {currentStep === steps.length - 1 ? 'Submit' : 'Next'}
                      </span>
                    </button>
                  </div>
                </div>
              ) : null}
            </div>

            {/* Progress Indicator */}
            <div className="px-4 pb-4">
              <div className="flex space-x-1">
                {steps.map((_, index) => (
                  <div
                    key={index}
                    className={`h-1 flex-1 rounded-full ${
                      index <= currentStep ? 'bg-primary-500' : 'bg-gray-200'
                    }`}
                  />
                ))}
              </div>
              <p className="text-xs text-gray-500 text-center mt-2">
                Step {currentStep + 1} of {steps.length}
              </p>
            </div>
          </div>
        </div>
      )}
    </>
  )
}

export default ChatBot
