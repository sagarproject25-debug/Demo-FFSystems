import React from 'react'
import { Link } from 'react-router-dom'
import { Flame, Phone, Mail, MapPin, Clock, Shield, Award, Users, ArrowRight } from 'lucide-react'

const Footer = () => {
  const currentYear = new Date().getFullYear()

  const footerLinks = {
    services: [
      { name: 'Fire Detection Systems', path: '/services' },
      { name: 'Fire Suppression', path: '/services' },
      { name: 'Safety Training', path: '/services' },
      { name: 'Compliance Services', path: '/services' },
    ],
    company: [
      { name: 'About Us', path: '/about' },
      { name: 'Our Team', path: '/about' },
      { name: 'Careers', path: '/about' },
      { name: 'News & Updates', path: '/about' },
    ],
    support: [
      { name: 'Contact Us', path: '/contact' },
      { name: 'Emergency Hotline', path: '/contact' },
      { name: 'Technical Support', path: '/contact' },
      { name: 'FAQ', path: '/contact' },
    ]
  }

  const contactInfo = [
    { icon: Phone, text: '+1 (555) 123-4567', link: 'tel:+15551234567' },
    { icon: Mail, text: 'info@fireguardpro.com', link: 'mailto:info@fireguardpro.com' },
    { icon: MapPin, text: '123 Safety Street, Fire City, FC 12345', link: '#' },
    { icon: Clock, text: '24/7 Emergency Response', link: '#' }
  ]

  const certifications = [
    { icon: Shield, text: 'ISO 9001 Certified', color: 'text-blue-600' },
    { icon: Award, text: 'NFPA Member', color: 'text-yellow-600' },
    { icon: Users, text: 'Licensed & Insured', color: 'text-green-600' }
  ]

  return (
    <footer className="bg-gray-900 text-white relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.1'%3E%3Ccircle cx='30' cy='30' r='2'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }} />
      </div>

      <div className="container-custom relative z-10">
        {/* Main Footer Content */}
        <div className="py-16">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Company Info */}
            <div className="lg:col-span-1">
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-12 h-12 bg-gradient-to-br from-primary-600 to-fire-500 rounded-xl flex items-center justify-center shadow-lg">
                  <Flame className="w-7 h-7 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-bold">FireGuard Pro</h3>
                  <p className="text-sm text-gray-400">Fire Safety Solutions</p>
                </div>
              </div>
              <p className="text-gray-300 mb-6 leading-relaxed">
                Protecting lives and property with expert fire safety solutions for over 20 years. 
                Your safety is our priority.
              </p>
              
              {/* Certifications */}
              <div className="space-y-3">
                {certifications.map((cert, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    <cert.icon className={`w-5 h-5 ${cert.color}`} />
                    <span className="text-sm text-gray-300">{cert.text}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Services */}
            <div>
              <h4 className="text-lg font-semibold mb-6 text-white">Services</h4>
              <ul className="space-y-3">
                {footerLinks.services.map((link, index) => (
                  <li key={index}>
                    <Link 
                      to={link.path} 
                      className="text-gray-300 hover:text-primary-400 transition-colors duration-200 flex items-center group"
                    >
                      <ArrowRight className="w-4 h-4 mr-2 group-hover:translate-x-1 transition-transform duration-200" />
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Company */}
            <div>
              <h4 className="text-lg font-semibold mb-6 text-white">Company</h4>
              <ul className="space-y-3">
                {footerLinks.company.map((link, index) => (
                  <li key={index}>
                    <Link 
                      to={link.path} 
                      className="text-gray-300 hover:text-primary-400 transition-colors duration-200 flex items-center group"
                    >
                      <ArrowRight className="w-4 h-4 mr-2 group-hover:translate-x-1 transition-transform duration-200" />
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Contact & Support */}
            <div>
              <h4 className="text-lg font-semibold mb-6 text-white">Contact & Support</h4>
              <ul className="space-y-3">
                {footerLinks.support.map((link, index) => (
                  <li key={index}>
                    <Link 
                      to={link.path} 
                      className="text-gray-300 hover:text-primary-400 transition-colors duration-200 flex items-center group"
                    >
                      <ArrowRight className="w-4 h-4 mr-2 group-hover:translate-x-1 transition-transform duration-200" />
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Contact Information */}
          <div className="mt-12 pt-8 border-t border-gray-800">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {contactInfo.map((info, index) => (
                <div key={index} className="flex items-center space-x-3 group">
                  <div className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center group-hover:bg-primary-600 transition-colors duration-200">
                    <info.icon className="w-5 h-5 text-gray-400 group-hover:text-white transition-colors duration-200" />
                  </div>
                  <div>
                    <a 
                      href={info.link} 
                      className="text-gray-300 hover:text-white transition-colors duration-200 text-sm"
                    >
                      {info.text}
                    </a>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom Footer */}
        <div className="py-6 border-t border-gray-800">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="text-gray-400 text-sm">
              © {currentYear} FireGuard Pro. All rights reserved.
            </div>
            <div className="flex items-center space-x-6 text-sm">
              <Link to="/privacy" className="text-gray-400 hover:text-white transition-colors duration-200">
                Privacy Policy
              </Link>
              <Link to="/terms" className="text-gray-400 hover:text-white transition-colors duration-200">
                Terms of Service
              </Link>
              <Link to="/sitemap" className="text-gray-400 hover:text-white transition-colors duration-200">
                Sitemap
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Emergency CTA */}
      <div className="bg-gradient-to-r from-primary-600 to-fire-600 py-4">
        <div className="container-custom text-center">
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-2 sm:space-y-0 sm:space-x-4">
            <span className="text-white font-semibold">Emergency? Call us 24/7:</span>
            <a 
              href="tel:+15551234567" 
              className="text-white text-lg font-bold hover:text-gray-200 transition-colors duration-200"
            >
              +1 (555) 123-4567
            </a>
          </div>
        </div>
      </div>
    </footer>
  )
}

export default Footer
