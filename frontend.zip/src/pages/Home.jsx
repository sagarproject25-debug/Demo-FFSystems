import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { Shield, Award, Users, ArrowRight, Flame, CheckCircle, Play, Star, Clock, MapPin } from 'lucide-react'

const Home = () => {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    setIsVisible(true)
  }, [])

  const highlights = [
    { icon: Shield, text: "20+ Years Experience", color: "text-blue-600", bgColor: "bg-blue-50" },
    { icon: Award, text: "Certified Safety Experts", color: "text-yellow-600", bgColor: "bg-yellow-50" },
    { icon: Users, text: "Trusted by Top Companies", color: "text-green-600", bgColor: "bg-green-50" }
  ]

  const features = [
    {
      icon: Flame,
      title: "Fire Detection Systems",
      description: "Advanced smoke and heat detection with 24/7 monitoring capabilities.",
      color: "from-red-500 to-red-600",
      bgColor: "bg-red-50"
    },
    {
      icon: Shield,
      title: "Safety Compliance",
      description: "Full compliance with local and international fire safety regulations.",
      color: "from-blue-500 to-blue-600",
      bgColor: "bg-blue-50"
    },
    {
      icon: Users,
      title: "Expert Team",
      description: "Certified professionals with extensive fire safety training and experience.",
      color: "from-green-500 to-green-600",
      bgColor: "bg-green-50"
    }
  ]

  const stats = [
    { number: "500+", label: "Projects Completed", icon: CheckCircle },
    { number: "20+", label: "Years Experience", icon: Clock },
    { number: "100%", label: "Safety Record", icon: Shield },
    { number: "24/7", label: "Emergency Support", icon: Star }
  ]

  const testimonials = [
    {
      name: "Sarah Johnson",
      company: "TechCorp Industries",
      text: "FireGuard Pro transformed our fire safety infrastructure. Their expertise and attention to detail are unmatched.",
      rating: 5
    },
    {
      name: "Michael Chen",
      company: "Global Manufacturing",
      text: "Professional service from start to finish. They exceeded our expectations in every aspect of the project.",
      rating: 5
    }
  ]

  return (
    <div className="min-h-screen pt-20">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 text-white overflow-hidden min-h-screen flex items-center">
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0" style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.1'%3E%3Ccircle cx='30' cy='30' r='2'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
          }} />
        </div>

        {/* Floating Elements */}
        <div className="absolute top-20 left-10 w-20 h-20 bg-primary-500/20 rounded-full animate-float"></div>
        <div className="absolute bottom-20 right-10 w-32 h-32 bg-fire-500/20 rounded-full animate-float" style={{animationDelay: '2s'}}></div>
        <div className="absolute top-1/2 right-20 w-16 h-16 bg-blue-500/20 rounded-full animate-float" style={{animationDelay: '4s'}}></div>

        <div className="container-custom relative z-10">
          <div className="flex flex-col lg:flex-row items-center min-h-screen py-20">
            <div className={`lg:w-1/2 text-center lg:text-left mb-12 lg:mb-0 transition-all duration-1000 ${
              isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-10'
            }`}>
              <div className="inline-flex items-center space-x-2 bg-white/10 backdrop-blur-sm rounded-full px-4 py-2 mb-6 border border-white/20">
                <Shield className="w-4 h-4 text-primary-400" />
                <span className="text-sm font-medium text-primary-200">Trusted by 500+ Companies</span>
              </div>
              
              <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold mb-8 leading-tight">
                Protecting Lives with
                <span className="block text-transparent bg-clip-text bg-gradient-to-r from-primary-400 to-fire-400 mt-2">
                  Expert Fire Fighting
                </span>
                Solutions
              </h1>
              
              <p className="text-xl text-gray-300 mb-10 max-w-2xl mx-auto lg:mx-0 leading-relaxed">
                We are a leading Fire Fighting Services provider with 20+ years of expertise 
                in fire detection, suppression, and safety compliance. Your safety is our priority.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start mb-12">
                <Link to="/services" className="btn-primary text-lg px-10 py-5 group">
                  Explore Our Services
                  <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform duration-200" />
                </Link>
                <Link to="/contact" className="btn-outline text-lg px-10 py-5 border-white text-white hover:bg-white hover:text-gray-900">
                  Get Free Consultation
                </Link>
              </div>

              {/* Trust Indicators */}
              <div className="flex items-center justify-center lg:justify-start space-x-8 text-sm text-gray-400">
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-4 h-4 text-green-400" />
                  <span>ISO Certified</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Shield className="w-4 h-4 text-blue-400" />
                  <span>Licensed & Insured</span>
                </div>
              </div>
            </div>
            
            <div className={`lg:w-1/2 flex justify-center transition-all duration-1000 delay-300 ${
              isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-10'
            }`}>
              <div className="relative">
                <div className="w-96 h-96 bg-gradient-to-br from-primary-500/30 to-fire-500/30 rounded-full animate-pulse-slow"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-80 h-80 bg-gradient-to-br from-primary-400 to-fire-400 rounded-full flex items-center justify-center shadow-2xl animate-float">
                    <Flame className="w-40 h-40 text-white" />
                  </div>
                </div>
                
                {/* Floating Stats */}
                <div className="absolute -top-4 -left-4 bg-white rounded-2xl p-4 shadow-xl animate-bounce-slow">
                  <div className="text-2xl font-bold text-primary-600">500+</div>
                  <div className="text-sm text-gray-600">Projects</div>
                </div>
                <div className="absolute -bottom-4 -right-4 bg-white rounded-2xl p-4 shadow-xl animate-bounce-slow" style={{animationDelay: '1s'}}>
                  <div className="text-2xl font-bold text-fire-600">24/7</div>
                  <div className="text-sm text-gray-600">Support</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Highlights Section */}
      <section className="section-padding bg-white">
        <div className="container-custom">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {highlights.map((highlight, index) => (
              <div key={index} className={`text-center p-8 rounded-2xl ${highlight.bgColor} hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2`}>
                <div className={`w-20 h-20 mx-auto mb-6 rounded-2xl ${highlight.bgColor} flex items-center justify-center shadow-lg`}>
                  <highlight.icon className={`w-10 h-10 ${highlight.color}`} />
                </div>
                <p className="text-xl font-semibold text-gray-800">{highlight.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="section-padding bg-gray-50">
        <div className="container-custom">
          <div className="text-center mb-20">
            <h2 className="section-title">
              Why Choose <span className="text-gradient">FireGuard Pro</span>?
            </h2>
            <p className="section-subtitle">
              We provide comprehensive fire safety solutions backed by decades of experience 
              and cutting-edge technology to ensure your complete protection.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div key={index} className={`feature-card ${feature.bgColor} group`}>
                <div className={`w-20 h-20 mx-auto mb-8 bg-gradient-to-br ${feature.color} rounded-2xl flex items-center justify-center shadow-lg group-hover:shadow-xl transition-all duration-300 transform group-hover:scale-110`}>
                  <feature.icon className="w-10 h-10 text-white" />
                </div>
                <h3 className="text-2xl font-semibold text-gray-900 mb-6 text-center">
                  {feature.title}
                </h3>
                <p className="text-gray-600 text-center leading-relaxed">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="section-padding bg-white">
        <div className="container-custom">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="stat-card group">
                <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-primary-500 to-fire-500 rounded-2xl flex items-center justify-center shadow-lg group-hover:shadow-xl transition-all duration-300">
                  <stat.icon className="w-8 h-8 text-white" />
                </div>
                <div className="text-4xl md:text-5xl font-bold text-primary-600 mb-2 group-hover:text-primary-700 transition-colors duration-300">
                  {stat.number}
                </div>
                <div className="text-gray-600 font-medium">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="section-padding bg-gray-50">
        <div className="container-custom">
          <div className="text-center mb-20">
            <h2 className="section-title">
              What Our <span className="text-gradient">Clients Say</span>
            </h2>
            <p className="section-subtitle">
              Don't just take our word for it. Here's what industry leaders have to say about our services.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2">
                <div className="flex items-center mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-700 mb-6 italic leading-relaxed">"{testimonial.text}"</p>
                <div>
                  <div className="font-semibold text-gray-900">{testimonial.name}</div>
                  <div className="text-sm text-gray-600">{testimonial.company}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding fire-gradient text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0" style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.1'%3E%3Ccircle cx='30' cy='30' r='2'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
          }} />
        </div>
        
        <div className="container-custom text-center relative z-10">
          <h2 className="text-4xl md:text-5xl font-bold mb-8">
            Ready to Protect Your Business?
          </h2>
          <p className="text-xl mb-10 max-w-3xl mx-auto opacity-90 leading-relaxed">
            Get a free consultation and quote for your fire safety needs. 
            Our experts are ready to help you create a safer environment for your team and assets.
          </p>
          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
            <Link to="/contact" className="bg-white text-fire-600 hover:bg-gray-100 font-semibold py-5 px-10 rounded-xl transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl text-lg">
              Get Free Quote
            </Link>
            <Link to="/services" className="border-2 border-white text-white hover:bg-white hover:text-fire-600 font-semibold py-5 px-10 rounded-xl transition-all duration-300 text-lg">
              View Services
            </Link>
          </div>
          
          <div className="mt-12 flex items-center justify-center space-x-8 text-sm opacity-80">
            <div className="flex items-center space-x-2">
              <Clock className="w-4 h-4" />
              <span>24/7 Emergency Response</span>
            </div>
            <div className="flex items-center space-x-2">
              <MapPin className="w-4 h-4" />
              <span>Nationwide Coverage</span>
            </div>
            <div className="flex items-center space-x-2">
              <Shield className="w-4 h-4" />
              <span>Licensed & Insured</span>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default Home
