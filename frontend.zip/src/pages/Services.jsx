import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { 
  Flame, 
  Droplets, 
  Wrench, 
  Users, 
  Building, 
  Shield, 
  CheckCircle, 
  ArrowRight,
  Phone,
  Mail,
  Star,
  Clock,
  Award,
  Zap
} from 'lucide-react'

const Services = () => {
  const [isVisible, setIsVisible] = useState(false)
  const [activeTab, setActiveTab] = useState(0)

  useEffect(() => {
    setIsVisible(true)
  }, [])

  const services = [
    {
      icon: Flame,
      title: "Fire Detection & Alarm Systems",
      description: "Advanced smoke and heat detection systems with intelligent alarm monitoring and notification capabilities.",
      features: [
        "Smoke detectors and heat sensors",
        "Intelligent alarm control panels",
        "24/7 monitoring services",
        "Emergency notification systems",
        "Integration with building management"
      ],
      color: "from-red-500 to-red-600",
      bgColor: "bg-red-50",
      price: "From $2,500"
    },
    {
      icon: Droplets,
      title: "Fire Suppression Systems",
      description: "Comprehensive fire suppression solutions including sprinkler systems, gas suppression, and foam systems.",
      features: [
        "Automatic sprinkler systems",
        "Clean agent gas suppression",
        "Foam suppression systems",
        "Kitchen hood suppression",
        "Special hazard protection"
      ],
      color: "from-blue-500 to-blue-600",
      bgColor: "bg-blue-50",
      price: "From $5,000"
    },
    {
      icon: Wrench,
      title: "Equipment Supply & Maintenance",
      description: "High-quality fire safety equipment supply and comprehensive maintenance services to ensure optimal performance.",
      features: [
        "Fire extinguishers and cabinets",
        "Emergency lighting systems",
        "Exit signs and wayfinding",
        "Preventive maintenance",
        "Emergency repair services"
      ],
      color: "from-green-500 to-green-600",
      bgColor: "bg-green-50",
      price: "From $1,200"
    },
    {
      icon: Users,
      title: "Emergency Response Training",
      description: "Comprehensive fire safety training programs for employees and emergency response teams.",
      features: [
        "Fire safety awareness training",
        "Evacuation procedures",
        "Fire extinguisher training",
        "Emergency response planning",
        "Regular safety drills"
      ],
      color: "from-purple-500 to-purple-600",
      bgColor: "bg-purple-50",
      price: "From $800"
    },
    {
      icon: Building,
      title: "Building Fire Safety Compliance",
      description: "Complete compliance solutions ensuring your building meets all local and international fire safety regulations.",
      features: [
        "Fire safety audits and inspections",
        "Compliance documentation",
        "Code interpretation and guidance",
        "Permit assistance",
        "Regular compliance reviews"
      ],
      color: "from-orange-500 to-orange-600",
      bgColor: "bg-orange-50",
      price: "From $1,500"
    },
    {
      icon: Shield,
      title: "Emergency Response Services",
      description: "24/7 emergency response services with rapid deployment of trained professionals and equipment.",
      features: [
        "24/7 emergency hotline",
        "Rapid response teams",
        "Emergency equipment deployment",
        "Coordination with local authorities",
        "Post-incident support"
      ],
      color: "from-indigo-500 to-indigo-600",
      bgColor: "bg-indigo-50",
      price: "From $3,000"
    }
  ]

  const additionalServices = [
    "Fire Safety Consulting",
    "Risk Assessment & Analysis",
    "Fire Safety Equipment Testing",
    "Emergency Lighting Design",
    "Fire Safety Signage",
    "Fire Safety Documentation"
  ]

  const processSteps = [
    {
      step: 1,
      title: "Assessment",
      description: "Comprehensive evaluation of your current fire safety systems and requirements.",
      icon: Shield,
      color: "from-primary-500 to-primary-600"
    },
    {
      step: 2,
      title: "Planning",
      description: "Custom solution design and project planning tailored to your needs.",
      icon: Wrench,
      color: "from-fire-500 to-fire-600"
    },
    {
      step: 3,
      title: "Implementation",
      description: "Professional installation and setup of all fire safety systems.",
      icon: Zap,
      color: "from-primary-500 to-primary-600"
    },
    {
      step: 4,
      title: "Support",
      description: "Ongoing maintenance, monitoring, and support services.",
      icon: Clock,
      color: "from-fire-500 to-fire-600"
    }
  ]

  const whyChooseUs = [
    {
      icon: Shield,
      title: "Expert Team",
      description: "Certified professionals with decades of experience in fire safety systems.",
      color: "from-primary-500 to-primary-600"
    },
    {
      icon: CheckCircle,
      title: "Quality Assurance",
      description: "All systems meet or exceed industry standards and regulatory requirements.",
      color: "from-fire-500 to-fire-600"
    },
    {
      icon: Phone,
      title: "24/7 Support",
      description: "Round-the-clock emergency response and technical support when you need it most.",
      color: "from-primary-500 to-primary-600"
    }
  ]

  return (
    <div className="min-h-screen pt-20">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-primary-600 via-primary-700 to-primary-800 text-white py-24 overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0" style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.1'%3E%3Ccircle cx='30' cy='30' r='2'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
          }} />
        </div>
        
        <div className="container-custom text-center relative z-10">
          <div className={`transition-all duration-1000 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}>
            <div className="inline-flex items-center space-x-2 bg-white/10 backdrop-blur-sm rounded-full px-4 py-2 mb-6 border border-white/20">
              <Shield className="w-4 h-4 text-primary-200" />
              <span className="text-sm font-medium text-primary-200">Professional Fire Safety Solutions</span>
            </div>
            
            <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold mb-8">
              Our Services
            </h1>
            <p className="text-xl text-primary-100 max-w-4xl mx-auto leading-relaxed">
              Comprehensive fire safety solutions designed to protect your business, 
              employees, and assets with cutting-edge technology and expert service.
            </p>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="section-padding bg-white">
        <div className="container-custom">
          <div className="text-center mb-20">
            <h2 className="section-title">
              Core <span className="text-gradient">Services</span>
            </h2>
            <p className="section-subtitle">
              We offer a complete range of fire safety services to meet all your protection needs.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div key={index} className={`feature-card ${service.bgColor} group hover:shadow-2xl transition-all duration-500`}>
                <div className={`w-20 h-20 mx-auto mb-8 bg-gradient-to-br ${service.color} rounded-2xl flex items-center justify-center shadow-lg group-hover:shadow-xl transition-all duration-300 transform group-hover:scale-110`}>
                  <service.icon className="w-10 h-10 text-white" />
                </div>
                
                <div className="text-center mb-6">
                  <h3 className="text-2xl font-semibold text-gray-900 mb-4">
                    {service.title}
                  </h3>
                  <p className="text-gray-600 leading-relaxed mb-4">
                    {service.description}
                  </p>
                  <div className="inline-block bg-gradient-to-r from-primary-500 to-fire-500 text-white px-4 py-2 rounded-full text-sm font-semibold">
                    {service.price}
                  </div>
                </div>
                
                <ul className="space-y-3 mb-8">
                  {service.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-start space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                      <span className="text-sm text-gray-600">{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <div className="text-center">
                  <Link 
                    to="/contact" 
                    className="inline-flex items-center text-primary-600 hover:text-primary-700 font-medium transition-colors group"
                  >
                    Get Quote
                    <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform duration-200" />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Additional Services */}
      <section className="section-padding bg-gray-50">
        <div className="container-custom">
          <div className="text-center mb-20">
            <h2 className="section-title">
              Additional <span className="text-gradient">Services</span>
            </h2>
            <p className="section-subtitle">
              Beyond our core offerings, we provide specialized services to meet 
              your unique fire safety requirements.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {additionalServices.map((service, index) => (
              <div key={index} className="bg-white p-6 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-100">
                <div className="flex items-center space-x-3">
                  <CheckCircle className="w-6 h-6 text-primary-600" />
                  <span className="text-gray-800 font-medium text-lg">{service}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Service Process */}
      <section className="section-padding bg-white">
        <div className="container-custom">
          <div className="text-center mb-20">
            <h2 className="section-title">
              Our Service <span className="text-gradient">Process</span>
            </h2>
            <p className="section-subtitle">
              A systematic approach to delivering exceptional fire safety solutions 
              tailored to your specific needs.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {processSteps.map((step, index) => (
              <div key={index} className="text-center group">
                <div className={`w-20 h-20 mx-auto mb-6 bg-gradient-to-br ${step.color} rounded-2xl flex items-center justify-center text-white font-bold text-2xl shadow-lg group-hover:shadow-xl transition-all duration-300 transform group-hover:scale-110`}>
                  <step.icon className="w-10 h-10" />
                </div>
                <h3 className="text-2xl font-semibold text-gray-900 mb-4">{step.title}</h3>
                <p className="text-gray-600 leading-relaxed">
                  {step.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="section-padding bg-gray-50">
        <div className="container-custom">
          <div className="text-center mb-20">
            <h2 className="section-title">
              Why Choose <span className="text-gradient">FireGuard Pro</span>?
            </h2>
            <p className="section-subtitle">
              Our commitment to excellence and safety sets us apart in the industry.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {whyChooseUs.map((item, index) => (
              <div key={index} className="text-center group">
                <div className={`w-20 h-20 mx-auto mb-6 bg-gradient-to-br ${item.color} rounded-2xl flex items-center justify-center shadow-lg group-hover:shadow-xl transition-all duration-300 transform group-hover:scale-110`}>
                  <item.icon className="w-10 h-10 text-white" />
                </div>
                <h3 className="text-2xl font-semibold text-gray-900 mb-4">{item.title}</h3>
                <p className="text-gray-600 leading-relaxed">
                  {item.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding fire-gradient text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0" style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.1'%3E%3Ccircle cx='30' cy='30' r='2'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
          }} />
        </div>
        
        <div className="container-custom text-center relative z-10">
          <h2 className="text-4xl md:text-5xl font-bold mb-8">
            Ready to Get Started?
          </h2>
          <p className="text-xl mb-10 max-w-3xl mx-auto opacity-90 leading-relaxed">
            Contact us today for a free consultation and quote. Our experts are ready 
            to discuss your fire safety needs and provide customized solutions.
          </p>
          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
            <Link to="/contact" className="bg-white text-fire-600 hover:bg-gray-100 font-semibold py-5 px-10 rounded-xl transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl text-lg">
              Get Free Quote
            </Link>
            <div className="flex items-center space-x-4 text-white">
              <div className="flex items-center space-x-2">
                <Phone className="w-5 h-5" />
                <span>+1 (555) 123-4567</span>
              </div>
              <div className="flex items-center space-x-2">
                <Mail className="w-5 h-5" />
                <span>info@fireguardpro.com</span>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default Services
